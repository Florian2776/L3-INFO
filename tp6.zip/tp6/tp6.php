<?php
/*
 * tp6.php
 * 
 * Copyright 2017 Florian BRUN <brunflo@inf-51-4>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>tp6</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="generator" content="Geany 1.27" />
</head>

<body>
  <h1>Table de multiplication de 9</h1>
  <?php
    $i = 1;
    while ($i <= 10) {
      echo "$i*9=";
      echo $i * 9;
      echo "<br>";
      $i++;
    }
  ?>
  
  <h1>Table de multiplication de 2 à 9</h1>
	<table>
  <?php
    $i = 1;
    //while ($i <= 10) {
      //echo "<tr><td>";
      //echo "$i*9";
      //echo "</td><td>"; 
      //echo $i * 9;
      //echo "</td></tr>";
      //$i++;
    //}
    
    while ($i <= 10) {
      echo "<tr>";
      echo "<td>$i*2=</td><td>".($i * 2)."</td>";  
      echo "<td>$i*3=</td><td>".($i * 3)."</td>";
      echo "<td>$i*4=</td><td>".($i * 4)."</td>";
      echo "<td>$i*5=</td><td>".($i * 5)."</td>";
      echo "<td>$i*6=</td><td>".($i * 6)."</td>";
      echo "<td>$i*7=</td><td>".($i * 7)."</td>";
      echo "<td>$i*8=</td><td>".($i * 8)."</td>";
      echo "<td>$i*9=</td><td>".($i * 9)."</td>";
      echo "</tr>";
      $i++;
    }
  ?>
  </table>
  
  <h1>Liste non ordonné à partir d'un tableau</h1>
  <?php 
    function titre($tab) {
        echo "<ul>"."<li>".implode("</li><li>", $tab)."</li>"."</ul>";
    }
    
    $tabl = array( 1 , 2 , 5 , 14 , 42 );
    titre($tabl);
  ?>
</body>

</html>
