<?php
/*
 * pendu.php
 * 
 * Copyright 2017 Florian BRUN <brunflo@inf-51-4>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */

  // démarrer une nouvelle session
  session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>Jeu du pendu</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="generator" content="Geany 1.27" />
</head>

<body>
  
  <?php
    // vérification de la connexion de la session   
    if (isset($_SESSION['pendu']) && $_SESSION['pendu']) {
  ?>
  
    <?php
      // l'utilisateur a trouvé le mot 
      if ($_SESSION['bons'] == [true, true, true, true, true, true]) {
      
        echo "<p>Félicitations !! Tu as gagné</p></span>";
      
      // l'utilisateur recherche le mot
      } else { 
        echo "<span class='lettre'><p>";
        for ($k = 0; $k < strlen($_POST['letter']); ++$k) {
          if (!$_SESSION['bons'][$k] && $_POST['letter'][$k] == $_SESSION['mot'][$k]) {
            $_SESSION['bons'][$k] = true;
            echo $_SESSION['mot'][$k];
          } else {
            array_push($_SESSION['erreurs'], $_POST['letter'][$k]);
            echo "&nbsp";
          }    
        }
        echo "</p></span>";
    ?>  
    
      <form method="POST" action="">
      <fieldset>
        <legend>Jeu du pendu</legend>
        <label for="proposition">Votre proposition :</label>
        <input type="text" name="letter" id="proposition" placeholder="?" pattern="[A-Za-z]{1}" required /><br/>
        <input type="reset" name="Effacer" /><br/> 
        <input type="submit" name="Envoyer" value="Envoyer"/>
      </fieldset>
    </form>
    
    <?php 
      }
    ?>
  <?php 
    } else {
       //header('Location: pendu.php');  
    }
  ?>
	
</body>

</html>
