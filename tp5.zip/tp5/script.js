function getDayToday() {
  d = new Date();
  m = (d.getMonth()+1);
  month = m >=10 ? m : "0"+m;
  return d.getDate()+"/"+month+"/"+d.getFullYear(); 
}

function dateNow1() {
  document.forms["form"].elements["date1"].value=getDayToday();
  document.forms["form"].elements["date1"].focus();
}

function dateNow2() {
  document.forms["form"].elements["date2"].value=getDayToday();
  document.forms["form"].elements["date2"].focus();
}

function diffDate(d1,d2){
  var WNbJours = d2 - d1;
  return Math.ceil(WNbJours/(1000*60*60*24));
}

function explose(d) {
  res = d.split("/");
  rslt = new Date(res[0], res[1], res[2]);
  return rslt;
}

function getDiffDate() {
  d1 = document.forms["form"].elements["date1"].value;
  d2 = document.forms["form"].elements["date2"].value;
  alert("Delta : "+diffDate(explose(d1), explose(d2))+"jour(s)");
}
